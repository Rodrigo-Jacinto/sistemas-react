import React from 'react';
import Home from './pages/home/home.js';


  const App = () => <Home />

  export default App;





