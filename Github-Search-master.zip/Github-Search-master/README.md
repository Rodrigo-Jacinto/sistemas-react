# Github Search
Sistema de busca de usuário do github feita com React,

Este projeto foi inicializado com o [npm init create-react] (https://github.com/facebook/create-react-app).

Sistema em produção: https://github-search-rodrigojacinto.herokuapp.com/



