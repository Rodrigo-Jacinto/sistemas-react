import React, { Component } from 'react';
import Login from './telas/login';


class App extends Component { 

  render() {
    
    return (
      <Login />
    );
    
  }
}

export default App;
