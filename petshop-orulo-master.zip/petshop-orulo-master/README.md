# petshop-orulo
Sistema de busca de cachorros feita com React,

Este projeto foi inicializado com o [Create React App] (https://github.com/facebook/create-react-app).
## Requisitos essenciais 
O computador que rodar a aplicação deve está conectado a internet, pois os sistema faz uso do framework Bootsrap por CDN, e seu backend está hospedado no https://cloud.mongodb.com e https://dashboard.heroku.com/

## Oque você precisa ter instalado na máquina

Node Js - v10.15.1 ou versão superior
NPM - 6.4.1 ou versão superior

é preciso que rode o comando "npm install" para que ele instale todas as dependências descristas no arquivdo "package.json";

## Scripts Disponíveis

No diretório do projeto, você pode executar:

### `npm start`

Executa o aplicativo no modo de desenvolvimento. <br>
Abra [http: // localhost: 3000] (http: // localhost: 3000) para visualizá-lo no navegador.

A página será recarregada se você fizer edições. <br>
Você também verá quaisquer erros de lint no console.



