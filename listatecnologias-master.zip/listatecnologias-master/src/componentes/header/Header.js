import React from 'react';
import './estilo.css';

const Header = () => <header id="main-header">JSHunt</header>

export default Header;